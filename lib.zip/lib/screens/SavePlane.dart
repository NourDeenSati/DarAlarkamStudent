import 'package:flutter/material.dart';

class SaveplaneScreen extends StatelessWidget {
  const SaveplaneScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('قريباً بعون الله ...')),
    );
  }
}